package dev.glacitecommissions.data;

/**
 * One line of the "Commissions:" section of the SkyBlock tab list.
 *
 * @param name    commission name exactly as shown in the tab list (e.g. "Citrine Gemstone Collector")
 * @param done    true if the tab list says DONE
 * @param percent progress 0..100
 */
public record Commission(String name, boolean done, double percent) {

    /** Progress as 0..1 (always 1 when done). */
    public double fraction() {
        return done ? 1.0 : Math.max(0.0, Math.min(1.0, percent / 100.0));
    }
}
