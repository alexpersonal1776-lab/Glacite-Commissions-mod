package dev.glacitecommissions.data;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.world.scores.PlayerTeam;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads the Hypixel SkyBlock tab list and extracts the "Commissions:" block.
 *
 * Hypixel builds its tab list out of fake players whose display names contain the text, e.g.
 *
 * <pre>
 *   Commissions:
 *    Citrine Gemstone Collector: 45.8%
 *    Umber Collector: DONE
 * </pre>
 *
 * This is purely read-only: the mod only looks at what the server already shows you.
 */
public final class CommissionTracker {

    /** "Name: 12.5%" or "Name: DONE" */
    private static final Pattern LINE = Pattern.compile(
            "^\\s*(.+?)\\s*:\\s*(DONE|(\\d+(?:\\.\\d+)?)\\s*%)\\s*$", Pattern.CASE_INSENSITIVE);

    /** Same ordering vanilla uses to lay out the tab list (team name, then profile name). */
    private static final Comparator<PlayerInfo> TAB_ORDER = Comparator
            .comparing(CommissionTracker::teamName)
            .thenComparing(p -> p.getProfile().name(), String.CASE_INSENSITIVE_ORDER);

    private static List<Commission> current = List.of();
    private static int tickCounter = 0;

    private CommissionTracker() {}

    /** Latest parsed commissions (empty if you are not somewhere that shows them). */
    public static List<Commission> current() {
        return current;
    }

    /** Called every client tick; only rescans every 10 ticks (0.5 s). */
    public static void tick(Minecraft mc) {
        ClientPacketListener connection = mc.getConnection();
        if (mc.player == null || connection == null) {
            current = List.of();
            return;
        }
        if (++tickCounter % 10 != 0) {
            return;
        }
        current = scan(connection);
    }

    private static List<Commission> scan(ClientPacketListener connection) {
        List<PlayerInfo> infos = new ArrayList<>(connection.getOnlinePlayers());
        infos.sort(TAB_ORDER);

        List<String> lines = new ArrayList<>(infos.size());
        for (PlayerInfo info : infos) {
            Component display = info.getTabListDisplayName();
            if (display == null) {
                continue;
            }
            // strip any literal section-sign colour codes, then trim
            lines.add(display.getString().replaceAll("\u00a7.", "").trim());
        }

        int start = -1;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).equalsIgnoreCase("Commissions:")) {
                start = i;
                break;
            }
        }
        if (start < 0) {
            return List.of();
        }

        List<Commission> result = new ArrayList<>(4);
        for (int i = start + 1; i < lines.size(); i++) {
            Matcher m = LINE.matcher(lines.get(i));
            if (!m.matches()) {
                break; // end of the commissions block
            }
            boolean done = m.group(2).equalsIgnoreCase("DONE");
            double pct = done ? 100.0 : Double.parseDouble(m.group(3));
            result.add(new Commission(m.group(1), done, pct));
        }
        return List.copyOf(result);
    }

    private static String teamName(PlayerInfo info) {
        PlayerTeam team = info.getTeam();
        return team == null ? "" : team.getName();
    }
}
