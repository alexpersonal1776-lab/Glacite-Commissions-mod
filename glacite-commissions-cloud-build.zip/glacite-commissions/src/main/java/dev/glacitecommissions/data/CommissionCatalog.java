package dev.glacitecommissions.data;

import java.util.List;
import java.util.Locale;

/**
 * Maps a commission name (as shown in the tab list) to an icon and a "what do I have to do" line.
 *
 * Matching is done on lower-cased substrings, first match wins, so put specific entries first
 * (e.g. "glacite walker" must come before "glacite").
 *
 * To add or fix a commission, just add/edit a line in {@link #ENTRIES}. Icons live in
 * assets/glacitecommissions/textures/gui/commission/&lt;icon&gt;.png
 * (see tools/generate_icons.py to regenerate or add new ones).
 */
public final class CommissionCatalog {

    public record Info(String icon, String task) {}

    private record Entry(String key, String icon, String task) {}

    private static final Info UNKNOWN = new Info("generic", "");

    private static final List<Entry> ENTRIES = List.of(
            // ---- Glacite Tunnels -------------------------------------------------------------
            new Entry("citrine",     "citrine",    "Mine 1,500 Citrine Gemstones"),
            new Entry("peridot",     "peridot",    "Mine 1,500 Peridot Gemstones"),
            new Entry("aquamarine",  "aquamarine", "Mine 1,500 Aquamarine Gemstones"),
            new Entry("onyx",        "onyx",       "Mine 1,500 Onyx Gemstones"),
            new Entry("umber",       "umber",      "Mine 1,500 Umber (or Enchanted Umber)"),
            new Entry("tungsten",    "tungsten",   "Mine 1,500 Tungsten (or Enchanted Tungsten)"),
            // must be before plain "glacite"
            new Entry("glacite walker", "walker",  "Slay 50 Glacite Walkers"),
            new Entry("glacite",     "glacite",    "Mine 1,500 Glacite (or Enchanted Glacite)"),
            new Entry("maniac",      "maniac",     "Slay 10 Glacite Maniacs in the Mineshafts"),
            new Entry("mineshaft",   "mineshaft",  "Discover a Glacite Mineshaft"),
            new Entry("corpse",      "corpse",     "Loot Frozen Corpses in the Mineshafts"),
            new Entry("scrap",       "scrap",      "Obtain 1 Suspicious Scrap"),

            // ---- Dwarven Mines (shown too, in case you are mining there) ----------------------
            new Entry("ice walker",  "walker",     "Slay 50 Ice Walkers"),
            new Entry("golden goblin", "goblin",   "Slay 1 Golden Goblin"),
            new Entry("goblin raid", "goblin",     "Slay 20 Goblins during the Goblin Raid"),
            new Entry("goblin",      "goblin",     "Slay 100 Goblins"),
            new Entry("treasure",    "treasure",   "Damage Treasure Hoarders 10 times"),
            new Entry("mithril miner", "mithril",  "Mine 350 Mithril Ore"),
            new Entry("mithril",     "mithril",    "Mine 250 Mithril Ore in the area"),
            new Entry("titanium miner", "titanium", "Mine 15 Titanium"),
            new Entry("titanium",    "titanium",   "Mine 10 Titanium Ore in the area")
    );

    private CommissionCatalog() {}

    public static Info lookup(String commissionName) {
        String n = commissionName.toLowerCase(Locale.ROOT);
        for (Entry e : ENTRIES) {
            if (n.contains(e.key())) {
                return new Info(e.icon(), e.task());
            }
        }
        return UNKNOWN;
    }
}
