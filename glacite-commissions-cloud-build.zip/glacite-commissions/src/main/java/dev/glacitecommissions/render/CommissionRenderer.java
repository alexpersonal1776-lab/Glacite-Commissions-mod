package dev.glacitecommissions.render;

import dev.glacitecommissions.GlaciteCommissionsClient;
import dev.glacitecommissions.config.CommissionConfig;
import dev.glacitecommissions.data.Commission;
import dev.glacitecommissions.data.CommissionCatalog;
import dev.glacitecommissions.data.CommissionTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Draws the commissions panel. Used both by the in-game HUD and by the config screen preview,
 * so what you position in the config screen is exactly what you get in game.
 *
 * All sizes below are in "unscaled panel units"; the whole panel is then scaled by config.scale.
 */
public final class CommissionRenderer {

    private static final int PAD = 4;
    private static final int ICON = 16;        // drawn size of an icon (textures are 32x32)
    private static final int ICON_TEX = 32;
    private static final int GAP = 4;          // gap between icon and text
    private static final int ROW_GAP = 4;
    private static final int BAR_H = 4;
    private static final int MIN_INNER_WIDTH = 120;

    private static final int COL_BG = 0xB0101018;
    private static final int COL_BORDER = 0xFF3A7BD5;
    private static final int COL_TITLE = 0xFF55D7FF;
    private static final int COL_NAME = 0xFFFFFFFF;
    private static final int COL_DONE = 0xFF55FF55;
    private static final int COL_DESC = 0xFFAAAAAA;
    private static final int COL_BAR_BG = 0xFF2A2A33;

    private static final String TITLE = "Commissions";

    private static final Map<String, Identifier> ICON_IDS = new HashMap<>();

    /** Unscaled panel size. */
    public record Size(int width, int height) {}

    private CommissionRenderer() {}

    /** Used as the HUD element. */
    public static void renderHud(GuiGraphicsExtractor graphics) {
        CommissionConfig cfg = CommissionConfig.get();
        if (!cfg.enabled) {
            return;
        }
        List<Commission> commissions = CommissionTracker.current();
        if (commissions.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        Size size = measure(mc.font, commissions, cfg);
        int x = clamp(cfg.x, 0, graphics.guiWidth() - Math.round(size.width() * cfg.scale));
        int y = clamp(cfg.y, 0, graphics.guiHeight() - Math.round(size.height() * cfg.scale));
        draw(graphics, mc.font, commissions, cfg, x, y);
    }

    // ---------------------------------------------------------------------------------------

    public static Size measure(Font font, List<Commission> list, CommissionConfig cfg) {
        int textX = textX(cfg);
        int inner = Math.max(MIN_INNER_WIDTH, font.width(TITLE));
        int height = PAD + font.lineHeight + 4;

        for (Commission c : list) {
            CommissionCatalog.Info info = CommissionCatalog.lookup(c.name());
            int pctW = font.width(percentText(c));
            int w = font.width(c.name()) + 8 + pctW;
            if (cfg.showDescriptions && !info.task().isEmpty()) {
                w = Math.max(w, font.width(info.task()));
            }
            inner = Math.max(inner, w);
            height += rowHeight(font, cfg, info) + ROW_GAP;
        }
        height += PAD - ROW_GAP;
        return new Size(textX + inner + PAD, height);
    }

    public static void draw(GuiGraphicsExtractor g, Font font, List<Commission> list,
                            CommissionConfig cfg, int x, int y) {
        Size size = measure(font, list, cfg);
        int w = size.width();
        int h = size.height();
        int textX = textX(cfg);

        g.pose().pushMatrix();
        g.pose().translate((float) x, (float) y);
        g.pose().scale(cfg.scale, cfg.scale);

        if (cfg.showBackground) {
            g.fill(0, 0, w, h, COL_BG);
            g.fill(0, 0, w, 1, COL_BORDER);
            g.fill(0, h - 1, w, h, COL_BORDER);
            g.fill(0, 0, 1, h, COL_BORDER);
            g.fill(w - 1, 0, w, h, COL_BORDER);
        }

        int cy = PAD;
        g.text(font, TITLE, PAD, cy, COL_TITLE, true);
        cy += font.lineHeight + 2;
        g.fill(PAD, cy, w - PAD, cy + 1, COL_BORDER);
        cy += 3;

        for (Commission c : list) {
            CommissionCatalog.Info info = CommissionCatalog.lookup(c.name());
            int rowH = rowHeight(font, cfg, info);
            boolean hasDesc = cfg.showDescriptions && !info.task().isEmpty();

            if (cfg.showIcons) {
                int iy = cy + (rowH - ICON) / 2;
                g.blit(RenderPipelines.GUI_TEXTURED, iconId(info.icon()), PAD, iy,
                        0f, 0f, ICON, ICON, ICON_TEX, ICON_TEX, ICON_TEX, ICON_TEX);
            }

            // vertically centre the text block next to the icon
            int textH = textHeight(font, cfg, info);
            int ty = cy + (rowH - textH) / 2;

            // line 1: name (left) + percent (right)
            String pct = percentText(c);
            g.text(font, c.name(), textX, ty, c.done() ? COL_DONE : COL_NAME, true);
            g.text(font, pct, w - PAD - font.width(pct), ty, c.done() ? COL_DONE : progressColor(c), true);
            ty += font.lineHeight;

            // line 2: what you have to do
            if (hasDesc) {
                g.text(font, info.task(), textX, ty + 1, COL_DESC, false);
                ty += font.lineHeight + 1;
            }

            // progress bar
            if (cfg.showProgressBars) {
                int bx1 = textX;
                int bx2 = w - PAD;
                int by = ty + 2;
                g.fill(bx1, by, bx2, by + BAR_H, COL_BAR_BG);
                int fillW = (int) Math.round((bx2 - bx1) * c.fraction());
                if (fillW > 0) {
                    g.fill(bx1, by, bx1 + fillW, by + BAR_H, c.done() ? COL_DONE : progressColor(c));
                }
            }
            cy += rowH + ROW_GAP;
        }

        g.pose().popMatrix();
    }

    // ---------------------------------------------------------------------------------------

    private static int textX(CommissionConfig cfg) {
        return PAD + (cfg.showIcons ? ICON + GAP : 0);
    }

    private static int textHeight(Font font, CommissionConfig cfg, CommissionCatalog.Info info) {
        int h = font.lineHeight;
        if (cfg.showDescriptions && !info.task().isEmpty()) {
            h += font.lineHeight + 1;
        }
        if (cfg.showProgressBars) {
            h += BAR_H + 2;
        }
        return h;
    }

    private static int rowHeight(Font font, CommissionConfig cfg, CommissionCatalog.Info info) {
        int h = textHeight(font, cfg, info);
        return cfg.showIcons ? Math.max(h, ICON) : h;
    }

    private static String percentText(Commission c) {
        return c.done() ? "DONE" : String.format("%.1f%%", c.percent());
    }

    private static int progressColor(Commission c) {
        double f = c.fraction();
        if (f < 0.34) {
            return 0xFFE05555;
        }
        if (f < 0.67) {
            return 0xFFE8B84A;
        }
        return 0xFF66D97A;
    }

    private static Identifier iconId(String icon) {
        return ICON_IDS.computeIfAbsent(icon, name -> Identifier.fromNamespaceAndPath(
                GlaciteCommissionsClient.MOD_ID, "textures/gui/commission/" + name + ".png"));
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(Math.max(min, max), v));
    }
}
