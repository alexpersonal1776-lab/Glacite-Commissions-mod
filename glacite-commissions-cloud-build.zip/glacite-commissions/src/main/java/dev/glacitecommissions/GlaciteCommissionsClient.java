package dev.glacitecommissions;

import dev.glacitecommissions.config.CommissionConfig;
import dev.glacitecommissions.data.CommissionTracker;
import dev.glacitecommissions.render.CommissionRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.resources.Identifier;

public class GlaciteCommissionsClient implements ClientModInitializer {

    public static final String MOD_ID = "glacitecommissions";

    @Override
    public void onInitializeClient() {
        CommissionConfig.load();

        // keep the parsed commissions fresh
        ClientTickEvents.END_CLIENT_TICK.register(CommissionTracker::tick);

        // draw the overlay on the HUD (after chat so it sits above most vanilla elements)
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "commissions"),
                (graphics, deltaTracker) -> CommissionRenderer.renderHud(graphics));
    }
}
