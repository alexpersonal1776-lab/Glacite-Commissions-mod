package dev.glacitecommissions.config;

import dev.glacitecommissions.data.Commission;
import dev.glacitecommissions.data.CommissionTracker;
import dev.glacitecommissions.render.CommissionRenderer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * Config screen opened from Mod Menu.
 * Drag the overlay with the left mouse button to move it; the buttons toggle what it shows.
 * Shows your real commissions if you are on SkyBlock, otherwise a sample.
 */
public class HudPositionScreen extends Screen {

    private static final List<Commission> SAMPLE = List.of(
            new Commission("Citrine Gemstone Collector", false, 45.8),
            new Commission("Umber Collector", false, 12.0),
            new Commission("Glacite Collector", true, 100.0),
            new Commission("Maniac Slayer", false, 70.0));

    private final Screen parent;
    private final CommissionConfig cfg = CommissionConfig.get();

    private boolean dragging = false;
    private double dragOffX;
    private double dragOffY;
    /** Overlay bounds (scaled, GUI px) from the last frame; used for hit testing. */
    private int boxW;
    private int boxH;

    private Button scaleLabel;

    public HudPositionScreen(Screen parent) {
        super(Component.literal("Glacite Commissions"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int bw = 100;
        int gap = 4;
        int left = (this.width - (bw * 3 + gap * 2)) / 2;
        int rowH = 24;
        int y = this.height - rowH * 4 - 8;

        // row 1
        addToggle(left, y, bw, "Overlay", () -> cfg.enabled, v -> cfg.enabled = v);
        addToggle(left + bw + gap, y, bw, "Icons", () -> cfg.showIcons, v -> cfg.showIcons = v);
        addToggle(left + (bw + gap) * 2, y, bw, "Tasks", () -> cfg.showDescriptions, v -> cfg.showDescriptions = v);
        y += rowH;

        // row 2
        addToggle(left, y, bw, "Bars", () -> cfg.showProgressBars, v -> cfg.showProgressBars = v);
        addToggle(left + bw + gap, y, bw, "Background", () -> cfg.showBackground, v -> cfg.showBackground = v);
        addRenderableWidget(Button.builder(Component.literal("Reset position"), b -> {
            cfg.x = CommissionConfig.DEFAULT_X;
            cfg.y = CommissionConfig.DEFAULT_Y;
            CommissionConfig.save();
        }).bounds(left + (bw + gap) * 2, y, bw, 20).build());
        y += rowH;

        // row 3: scale
        addRenderableWidget(Button.builder(Component.literal("Scale -"), b -> changeScale(-0.25f))
                .bounds(left, y, bw, 20).build());
        scaleLabel = addRenderableWidget(Button.builder(scaleText(), b -> {
            cfg.scale = 1.0f;
            CommissionConfig.save();
            scaleLabel.setMessage(scaleText());
        }).bounds(left + bw + gap, y, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Scale +"), b -> changeScale(0.25f))
                .bounds(left + (bw + gap) * 2, y, bw, 20).build());
        y += rowH;

        // row 4
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(this.width / 2 - 102, y, 204, 20).build());
    }

    private void addToggle(int x, int y, int w, String label, BooleanSupplier get, Consumer<Boolean> set) {
        Button[] self = new Button[1];
        self[0] = Button.builder(toggleText(label, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            self[0].setMessage(toggleText(label, get.getAsBoolean()));
            CommissionConfig.save();
        }).bounds(x, y, w, 20).build();
        addRenderableWidget(self[0]);
    }

    private static Component toggleText(String label, boolean on) {
        return Component.literal(label + ": " + (on ? "ON" : "OFF"));
    }

    private Component scaleText() {
        return Component.literal(String.format("Scale: %.2fx", cfg.scale));
    }

    private void changeScale(float delta) {
        cfg.scale = Math.max(0.5f, Math.min(3.0f, Math.round((cfg.scale + delta) * 100f) / 100f));
        scaleLabel.setMessage(scaleText());
        CommissionConfig.save();
    }

    // ---------------------------------------------------------------------------------------

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);

        String hint = "Drag the overlay to move it";
        graphics.text(this.font, hint, (this.width - this.font.width(hint)) / 2, 10, 0xFFFFFFFF, true);
        String hint2 = CommissionTracker.current().isEmpty()
                ? "(showing sample data: your real commissions appear here on SkyBlock)"
                : "(showing your real commissions)";
        graphics.text(this.font, hint2, (this.width - this.font.width(hint2)) / 2, 22, 0xFFAAAAAA, true);

        List<Commission> list = CommissionTracker.current().isEmpty() ? SAMPLE : CommissionTracker.current();
        CommissionRenderer.Size size = CommissionRenderer.measure(this.font, list, cfg);
        boxW = Math.round(size.width() * cfg.scale);
        boxH = Math.round(size.height() * cfg.scale);

        cfg.x = clamp(cfg.x, 0, this.width - boxW);
        cfg.y = clamp(cfg.y, 0, this.height - boxH);

        CommissionRenderer.draw(graphics, this.font, list, cfg, cfg.x, cfg.y);

        // dashed-looking bounding box so you can see what you are grabbing
        int col = dragging ? 0xFFFFFF55 : 0x88FFFFFF;
        graphics.fill(cfg.x - 1, cfg.y - 1, cfg.x + boxW + 1, cfg.y, col);
        graphics.fill(cfg.x - 1, cfg.y + boxH, cfg.x + boxW + 1, cfg.y + boxH + 1, col);
        graphics.fill(cfg.x - 1, cfg.y, cfg.x, cfg.y + boxH, col);
        graphics.fill(cfg.x + boxW, cfg.y, cfg.x + boxW + 1, cfg.y + boxH, col);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0 && inside(event.x(), event.y())) {
            dragging = true;
            dragOffX = event.x() - cfg.x;
            dragOffY = event.y() - cfg.y;
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragging) {
            cfg.x = clamp((int) Math.round(event.x() - dragOffX), 0, this.width - boxW);
            cfg.y = clamp((int) Math.round(event.y() - dragOffY), 0, this.height - boxH);
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging) {
            dragging = false;
            CommissionConfig.save();
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public void onClose() {
        CommissionConfig.save();
        this.minecraft.setScreen(parent);
    }

    private boolean inside(double mx, double my) {
        return mx >= cfg.x && mx <= cfg.x + boxW && my >= cfg.y && my <= cfg.y + boxH;
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(Math.max(min, max), v));
    }
}
