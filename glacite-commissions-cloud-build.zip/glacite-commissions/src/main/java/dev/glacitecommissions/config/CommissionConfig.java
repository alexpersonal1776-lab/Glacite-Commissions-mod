package dev.glacitecommissions.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Saved to .minecraft/config/glacite_commissions.json */
public final class CommissionConfig {

    public static final int DEFAULT_X = 6;
    public static final int DEFAULT_Y = 40;

    public boolean enabled = true;
    /** Top-left corner of the overlay, in GUI-scaled pixels. */
    public int x = DEFAULT_X;
    public int y = DEFAULT_Y;
    public float scale = 1.0f;
    public boolean showIcons = true;
    public boolean showDescriptions = true;
    public boolean showProgressBars = true;
    public boolean showBackground = true;

    // ---------------------------------------------------------------------------------------

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static CommissionConfig instance = new CommissionConfig();

    public static CommissionConfig get() {
        return instance;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("glacite_commissions.json");
    }

    public static void load() {
        Path path = file();
        if (Files.exists(path)) {
            try (Reader reader = Files.newBufferedReader(path)) {
                CommissionConfig loaded = GSON.fromJson(reader, CommissionConfig.class);
                if (loaded != null) {
                    instance = loaded;
                }
            } catch (IOException | RuntimeException e) {
                System.err.println("[GlaciteCommissions] Could not read config, using defaults: " + e);
            }
        }
        instance.scale = Math.max(0.5f, Math.min(3.0f, instance.scale));
        save();
    }

    public static void save() {
        try (Writer writer = Files.newBufferedWriter(file())) {
            GSON.toJson(instance, writer);
        } catch (IOException e) {
            System.err.println("[GlaciteCommissions] Could not save config: " + e);
        }
    }
}
