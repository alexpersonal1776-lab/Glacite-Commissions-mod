# Glacite Commissions Overlay

Fabric mod for **Minecraft 26.1.2** (Java 25) that shows your current Hypixel SkyBlock commissions
(Glacite Tunnels, plus Dwarven Mines ones) as a HUD overlay, with an icon and a task line for each,
e.g. a Citrine gem and "Mine 1,500 Citrine Gemstones".

It only reads the "Commissions:" section of the tab list that Hypixel already sends you. Nothing is
sent anywhere and nothing is automated.

## Using it
1. Install Fabric Loader (0.20.1+), Fabric API, and (optionally) **Mod Menu**.
2. Drop the jar in `mods/`.
3. Mod Menu -> *Glacite Commissions Overlay* -> **Configure**.
   - Drag the overlay with the left mouse button to move it.
   - Toggle Overlay / Icons / Tasks / Bars / Background, change Scale, Reset position.
4. Settings are saved to `config/glacite_commissions.json` (you can also edit x / y there).

## Building
You need JDK 25.

The Gradle wrapper files aren't included. Easiest: copy `gradlew`, `gradlew.bat` and the `gradle/`
folder from https://github.com/FabricMC/fabric-example-mod (branch `26.1.2`) into this folder, or run
`gradle wrapper` if you have Gradle installed. Then:

    ./gradlew build          # jar ends up in build/libs/
    ./gradlew runClient      # dev client (Mod Menu is included in dev)

## Adding / fixing commissions
Edit `data/CommissionCatalog.java`. Each line is `keyword -> icon -> task text`. The keyword is matched
against the commission name from the tab list (case-insensitive, first match wins). Unknown commissions
still show, with a pickaxe icon and no task line.

Icons are 32x32 PNGs in `src/main/resources/assets/glacitecommissions/textures/gui/commission/`.
`python3 tools/generate_icons.py` regenerates them (requires Pillow); they are drawn from scratch,
not ripped from the game.
