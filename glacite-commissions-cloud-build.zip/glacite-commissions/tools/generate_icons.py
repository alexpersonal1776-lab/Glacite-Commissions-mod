#!/usr/bin/env python3
"""
Generates the 32x32 commission icons used by the overlay.

All icons are drawn procedurally (no copyrighted game art is used), supersampled
at 128x128 and downscaled to 32x32. The overlay draws them at 16 GUI units, so
they map 1:1 to physical pixels at GUI scale 2 and stay crisp at scale 4.

Run:  python3 tools/generate_icons.py
"""
import os
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources",
                   "assets", "glacitecommissions", "textures", "gui", "commission")
os.makedirs(OUT, exist_ok=True)

S = 128  # supersample canvas


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c[:3]) + (255,)


def new():
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    return img, ImageDraw.Draw(img)


def outline(d, pts, color, w=4):
    d.line(list(pts) + [pts[0]], fill=color, width=w, joint="curve")


def gem(d, base, cx=64, cy=64, k=1.0):
    """Classic faceted gem. cx,cy = centre, k = scale."""
    def p(x, y):
        return (cx + (x - 64) * k, cy + (y - 64) * k)

    A, B, C, D, E = p(34, 28), p(94, 28), p(116, 52), p(64, 112), p(12, 52)
    L, R = p(46, 52), p(82, 52)
    facets = [
        ([A, B, R, L], 1.40),   # table
        ([A, L, E], 1.18),      # crown left
        ([B, C, R], 1.00),      # crown right
        ([E, L, D], 0.82),      # pavilion left
        ([L, R, D], 1.08),      # pavilion centre
        ([R, C, D], 0.62),      # pavilion right
    ]
    for pts, f in facets:
        d.polygon(pts, fill=shade(base, f))
    outline(d, [A, B, C, D, E], shade(base, 0.38), max(2, int(4 * k)))
    d.line([E, C], fill=shade(base, 0.55), width=max(1, int(2 * k)))
    # sparkle
    s1, s2, s3 = p(44, 36), p(60, 36), p(52, 46)
    d.polygon([s1, s2, s3], fill=(255, 255, 255, 170))


def rock(d, base=(96, 98, 104), cx=64, cy=70):
    pts = [(14, 84), (20, 52), (40, 34), (70, 28), (98, 40), (114, 66), (108, 96), (80, 108), (40, 106)]
    pts = [(x + cx - 64, y + cy - 70) for x, y in pts]
    d.polygon(pts, fill=base)
    # lighter top-left plane + darker bottom plane
    d.polygon([pts[1], pts[2], pts[3], pts[4], (64, 64)], fill=shade(base, 1.2))
    d.polygon([pts[5], pts[6], pts[7], pts[8], (64, 70)], fill=shade(base, 0.72))
    outline(d, pts, shade(base, 0.35), 4)


def ore(crystal, rock_color=(96, 98, 104), spots=((46, 60, 0.55), (82, 54, 0.5), (66, 88, 0.6))):
    img, d = new()
    rock(d, rock_color)
    for x, y, k in spots:
        gem(d, crystal, x, y, k)
    return img


def glacite():
    img, d = new()
    base = (150, 225, 255)

    def crystal(cx, top, bot, w, f):
        pts_l = [(cx - w, bot), (cx - w, top + 26), (cx, top)]
        pts_r = [(cx + w, bot), (cx + w, top + 26), (cx, top)]
        mid = [(cx - w, bot), (cx + w, bot), (cx + w, top + 26), (cx, top), (cx - w, top + 26)]
        d.polygon(mid, fill=shade(base, 0.9 * f))
        d.polygon([(cx - w, bot), (cx, bot), (cx, top), (cx - w, top + 26)], fill=shade(base, 1.2 * f))
        d.polygon([(cx, bot), (cx + w, bot), (cx + w, top + 26), (cx, top)], fill=shade(base, 0.7 * f))
        outline(d, mid, shade(base, 0.35), 3)
        d.polygon([(cx - w + 6, top + 36), (cx - w + 12, top + 36), (cx - w + 12, bot - 16), (cx - w + 6, bot - 16)],
                  fill=(255, 255, 255, 150))

    crystal(36, 52, 112, 17, 0.85)
    crystal(92, 44, 112, 17, 0.9)
    crystal(64, 14, 114, 22, 1.05)
    return img


def head(skin, eye, extra=None, horns=None, ears=None):
    img, d = new()
    if ears:
        d.polygon([(24, 56), (2, 34), (30, 40)], fill=shade(skin, 0.85))
        d.polygon([(104, 56), (126, 34), (98, 40)], fill=shade(skin, 0.85))
    d.rounded_rectangle((20, 24, 108, 112), radius=12, fill=skin, outline=shade(skin, 0.4), width=4)
    d.rectangle((24, 28, 104, 44), fill=shade(skin, 1.15))
    d.rectangle((34, 56, 54, 72), fill=eye)
    d.rectangle((74, 56, 94, 72), fill=eye)
    d.rectangle((38, 60, 46, 68), fill=(20, 20, 20, 255))
    d.rectangle((78, 60, 86, 68), fill=(20, 20, 20, 255))
    d.rectangle((40, 88, 88, 98), fill=shade(skin, 0.4))
    if extra == "fangs":
        d.polygon([(46, 98), (54, 98), (50, 110)], fill=(255, 255, 255, 255))
        d.polygon([(74, 98), (82, 98), (78, 110)], fill=(255, 255, 255, 255))
    if extra == "frost":
        for x in (28, 52, 76, 100):
            d.polygon([(x, 28), (x + 10, 28), (x + 5, 6)], fill=(235, 250, 255, 255))
    if extra == "scar":
        d.line([(30, 36), (60, 100)], fill=(120, 20, 20, 255), width=5)
    return img


def chest():
    img, d = new()
    wood = (150, 98, 48)
    d.rounded_rectangle((12, 44, 116, 110), radius=6, fill=wood, outline=shade(wood, 0.4), width=4)
    d.rounded_rectangle((12, 30, 116, 58), radius=12, fill=shade(wood, 1.2), outline=shade(wood, 0.4), width=4)
    d.rectangle((12, 54, 116, 62), fill=(235, 190, 60, 255))
    d.rectangle((54, 52, 74, 78), fill=(245, 205, 70, 255), outline=(120, 90, 20, 255), width=3)
    d.rectangle((61, 62, 67, 72), fill=(60, 40, 10, 255))
    for x in (28, 94):
        d.rectangle((x, 44, x + 8, 110), fill=(120, 120, 128, 255))
    return img


def cog(color=(176, 168, 150)):
    img, d = new()
    import math
    cx = cy = 64
    for i in range(8):
        a = i * math.pi / 4
        x, y = cx + math.cos(a) * 46, cy + math.sin(a) * 46
        d.regular_polygon((x, y, 15), 4, rotation=math.degrees(a), fill=shade(color, 0.85), outline=shade(color, 0.4))
    d.ellipse((20, 20, 108, 108), fill=color, outline=shade(color, 0.4), width=4)
    d.ellipse((30, 30, 98, 98), outline=shade(color, 0.7), width=4)
    d.ellipse((48, 48, 80, 80), fill=(0, 0, 0, 0), outline=shade(color, 0.4), width=4)
    d.ellipse((50, 50, 78, 78), fill=(40, 40, 44, 255))
    d.text((57, 52), "?", fill=(255, 220, 100, 255))
    return img


def mineshaft():
    img, d = new()
    wood = (140, 96, 52)
    d.rectangle((16, 18, 112, 116), fill=(24, 26, 34, 255))
    d.rectangle((16, 18, 112, 116), outline=shade(wood, 0.45), width=4)
    d.rectangle((10, 14, 28, 118), fill=wood, outline=shade(wood, 0.4), width=3)
    d.rectangle((100, 14, 118, 118), fill=wood, outline=shade(wood, 0.4), width=3)
    d.rectangle((6, 8, 122, 26), fill=shade(wood, 1.15), outline=shade(wood, 0.4), width=3)
    # rails going into the dark
    d.polygon([(44, 116), (56, 116), (62, 56), (60, 56)], fill=(150, 150, 160, 255))
    d.polygon([(72, 116), (84, 116), (68, 56), (66, 56)], fill=(150, 150, 160, 255))
    for y in (100, 86, 74, 64):
        d.line([(50 - (100 - y) * 0.12, y), (78 + (100 - y) * 0.12, y)], fill=shade(wood, 0.9), width=4)
    # glowing eyes in the dark
    d.ellipse((50, 40, 58, 46), fill=(255, 80, 60, 255))
    d.ellipse((70, 40, 78, 46), fill=(255, 80, 60, 255))
    return img


def corpse():
    img, d = new()
    ice = (170, 225, 245)
    d.rounded_rectangle((16, 12, 112, 116), radius=10, fill=shade(ice, 0.9), outline=shade(ice, 0.4), width=4)
    d.rectangle((20, 16, 108, 34), fill=shade(ice, 1.2))
    d.ellipse((48, 30, 80, 62), fill=(40, 52, 70, 255))
    d.rounded_rectangle((38, 62, 90, 108), radius=8, fill=(40, 52, 70, 255))
    d.line([(26, 100), (50, 74)], fill=(255, 255, 255, 120), width=4)
    d.line([(88, 28), (104, 44)], fill=(255, 255, 255, 120), width=4)
    return img


def pickaxe():
    img, d = new()
    wood, steel = (140, 96, 52), (170, 176, 186)
    d.line([(26, 108), (96, 38)], fill=shade(wood, 0.45), width=16)
    d.line([(26, 108), (96, 38)], fill=wood, width=10)
    head = [(28, 30), (60, 14), (104, 22), (116, 66), (100, 94), (104, 56), (92, 40), (60, 34)]
    d.polygon(head, fill=steel)
    outline(d, head, shade(steel, 0.35), 4)
    d.polygon([(40, 28), (60, 20), (96, 26), (60, 34)], fill=shade(steel, 1.25))
    return img


def tungsten():
    return ore((120, 150, 190), rock_color=(70, 74, 82),
               spots=((44, 62, 0.5), (84, 58, 0.55), (62, 88, 0.55)))


ICONS = {
    # Glacite Tunnels gemstones / ores
    "citrine":    lambda: gem_icon((252, 196, 40)),
    "peridot":    lambda: gem_icon((120, 210, 70)),
    "aquamarine": lambda: gem_icon((90, 200, 235)),
    "onyx":       lambda: gem_icon((74, 66, 104)),
    "umber":      lambda: ore((176, 108, 52), rock_color=(104, 82, 64)),
    "tungsten":   tungsten,
    "glacite":    glacite,
    # Dwarven Mines ores
    "mithril":    lambda: ore((86, 190, 205), rock_color=(96, 106, 116)),
    "titanium":   lambda: ore((214, 222, 232), rock_color=(88, 92, 100)),
    # misc commissions
    "walker":     lambda: head((150, 210, 235), (255, 255, 255, 255), extra="frost"),
    "maniac":     lambda: head((96, 100, 112), (255, 60, 40, 255), extra="scar"),
    "goblin":     lambda: head((96, 168, 74), (255, 220, 70, 255), extra="fangs", ears=True),
    "treasure":   chest,
    "scrap":      cog,
    "mineshaft":  mineshaft,
    "corpse":     corpse,
    "generic":    pickaxe,
}


def gem_icon(color):
    img, d = new()
    gem(d, color, 64, 64, 1.0)
    return img


if __name__ == "__main__":
    for name, fn in ICONS.items():
        im = fn().resize((32, 32), Image.LANCZOS)
        im.save(os.path.join(OUT, name + ".png"))
        print("wrote", name)

    # mod icon (128x128)
    icon_dir = os.path.join(OUT, "..", "..", "..")
    gem_icon((252, 196, 40)).save(os.path.join(icon_dir, "icon.png"))
    print("wrote mod icon")
